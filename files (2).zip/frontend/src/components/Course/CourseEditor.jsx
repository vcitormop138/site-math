// Même composant que pour créer, mais on utilise les valeurs existantes
// On ajoute un bouton "Modifier"